//victim.cpp
#include "../include/robotPlanning/victim.hpp"